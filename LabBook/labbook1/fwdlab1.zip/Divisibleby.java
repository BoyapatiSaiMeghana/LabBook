package lab1programs;

import java.util.Scanner;

public class Divisibleby 
{ 
	int sum=0;
	public int calculateSum()
	{
		Scanner s=new Scanner(System.in);
		int n= s.nextInt();  
		for(int i=1;i<=n;i++)
		{
			if(i%3==0 || i%5==0)
			{
				sum=sum+i;
			}
		}
		System.out.println(sum);
		s.close();
		return n;
	}
		
		public static void main(String args[])
		{
			Divisibleby s=new Divisibleby();
			s.calculateSum(); 
			
		}
}


